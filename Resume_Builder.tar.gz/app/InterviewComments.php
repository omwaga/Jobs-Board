<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InterviewComments extends Model
{
    //
}
