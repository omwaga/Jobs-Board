<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InterviewCommentsController extends Controller
{
    //
}
