<h4 class="pb-3">More Resources</h4>
<div class="row d-flex justify-content-center">
  <div class="col-md-3 card d-flex ftco-animate m-2">
    <div class="blog-entry align-self-stretch">
      <div class="text mt-3">
        <h3 class="heading"><a href="{{route('front.vacancies')}}">Job Listings</a></h3>
        <p>Job Listings</p>
      </div>
    </div>
  </div>
  <div class="col-md-3 card d-flex ftco-animate m-2">
    <div class="blog-entry align-self-stretch">
      <div class="text mt-3">
        <h3 class="heading"><a href="{{route('front.blog')}}">Blog</a></h3>
        <p>Blog Articles</p>
      </div>
    </div>
  </div>
  <div class="col-md-3 card d-flex ftco-animate m-2">
    <div class="blog-entry align-self-stretch">
      <div class="text mt-3">
        <h3 class="heading"><a href="">Cheat Sheets</a></h3>
        <p>Cheat Sheets</p>
      </div>
    </div>
  </div>
</div>